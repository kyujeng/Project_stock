package com.jh.dividendpj.config;

public class CacheKey {
    public static final String KEY_FINANCE = "finance";
}
